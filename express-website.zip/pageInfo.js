const pageInfo = {
  index: {
    name: "home",
    title: 'Food Ipsum',
    description: 'The most delicious ipsum'
  },
  bacon: {
    name: "bacon",
    title: 'Bacon Ipsum',
    description: 'Smoky',
  },
  cheeseburger: {
    name: "cheeseburger",
    title: 'Coffee Ipsum',
    description: 'Steamy',
  },
  cupcake: {
    name: "cupcake",
    title: 'Cupcake Ipsum',
    description: 'Sweet',
  }
}

module.exports = pageInfo;